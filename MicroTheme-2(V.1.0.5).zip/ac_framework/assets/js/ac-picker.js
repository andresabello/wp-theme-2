(function( $ ) {




    $(function() {    




        // Add Color Picker to all inputs that have 'color-field' class




        $( '.ac-color-picker' ).wpColorPicker();




         




    });




})( jQuery );