<?php get_header(); ?>




	<div class="row">




		<div class="span12" id="four">




			<h2>Sorry, page not found!</h2>




			<p>Go back <a href="<?php bloginfo('home'); ?>">Homepage</a></p>




		</div>




	</div>




<?php get_footer(); ?>